# 2DHelicopterGame
A simple 2DHelicopter record game using scrolling bitmaps and canvas based on a tutorial I found on youtube by 
[paymon wang-lotfi](https://www.youtube.com/user/Paymon112233). 

<img src="https://github.com/mrshamshir/2DHelicopterGame/blob/master/Screenshot.png" width="600">

it's a simple game for beginners to android and those who want to start with simple 2D games
